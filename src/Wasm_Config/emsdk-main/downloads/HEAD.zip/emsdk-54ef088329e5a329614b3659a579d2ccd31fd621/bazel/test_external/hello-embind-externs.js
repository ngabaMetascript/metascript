// This file prevents customJSFunctionToTestClosure from being minified by the Closure compiler.
Module.customJSFunctionToTestClosure = function() {}